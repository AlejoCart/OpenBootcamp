package com.example.Ejercicio_4_5_6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejercicio456ApplicationTests {

	@Test
	void contextLoads() {
	}

}
